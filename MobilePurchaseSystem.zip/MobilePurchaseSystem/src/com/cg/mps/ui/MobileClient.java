package com.cg.mps.ui;
import java.util.ArrayList;
import java.util.Scanner;
import com.cg.mps.bean.Mobile;
import com.cg.mps.bean.Purchase;
import com.cg.mps.exception.MobileException;
import com.cg.mps.service.MpsService;
import com.cg.mps.service.MpsServiceImpl;

public class MobileClient 
{
	static Scanner sc=null;
	static MpsService mpsSer=null;
	public static void main(String[] args) 
	{
		mpsSer=new MpsServiceImpl();
		sc=new Scanner(System.in);
		int choice=0;
		while(true)
		{
			System.out.println("What do you want to perform?");
			System.out.println("1:Insert Purchase details \t  2.Fetch details \t 3.Delete based on mobileId \t 4.Search based on price range 5.Exit \t");
			choice=sc.nextInt();
			switch(choice)
			{
			case 1:insertPurchase();
			break;
			case 2:fetchAll();
		    break;
			case 3:delete();
			break;
			case 4:search();
			break;
			default:
			System.exit(0);
			}
		}
	}
/*******************main ends here**********************/

	public static void insertPurchase()
	{
		System.out.println("Enter Customer Name: ");
		String custName=sc.next();
		try 
		{
		if(mpsSer.validateName(custName))
		{
			System.out.println("Enter Customer Email Id");
			String custEmail =sc.next();
			if(mpsSer.validateMail(custEmail))
			{
				System.out.println("Enter Phone Number");
				String custPhoneNo = sc.next();
				if(mpsSer.validateDigit(custPhoneNo))
				{
					System.out.println("Enter Mobile Id");
					int mobId = sc.nextInt();
					
					Purchase pd=new Purchase();
					Mobile m= new Mobile();
					pd.setcName(custName);
					pd.setMailId(custEmail);
					pd.setPhoneNo(custPhoneNo);
					m.setMobId(mobId);
					
					int dataAdded = mpsSer.addPur(pd,m);
					if(dataAdded==1)
					{
						System.out.println("Purchase Details Added....");
					}
						else
						{
							System.out.println("May raise an exception while addition");
						}
					}	
				}
			}
		}
	catch (MobileException e)
	{
		System.out.println(e.getMessage());
	}
	}
/***************************************************/
	public static void fetchAll()
	{
		System.out.println("Mobile details are: ");
		try
		{
			ArrayList<Mobile> mpsList= mpsSer.getAllMps();
			
			for(Mobile ml:mpsList)
			{
				System.out.println(ml);
			}
		}
	catch (MobileException e)
	{
		System.out.println(e.getMessage());
	}
}	
/***************************************************/	
	public static void delete()
	{
		System.out.println("Enter mobile id");
		int mid=sc.nextInt();
		try
		{
			int dataDeleted=mpsSer.deleteMob(mid);
			if(dataDeleted==1)
			{
				System.out.println("Mobile data deleted");
			}
			else
			{
				System.out.println("May raise an exception while deletion");
			}
		}
	catch (MobileException e)
	{
		System.out.println(e.getMessage());
	}
}
/***************************************************/
	public static void search()
	{
		System.out.println("Enter min price");
		int mPrice1=sc.nextInt();
		System.out.println("Enter max price");
		int mPrice2=sc.nextInt();
		try
		{
			ArrayList<Mobile> mList= mpsSer.getSearchMps(mPrice1,mPrice2);
			
			for(Mobile mm:mList)
			{
				System.out.println(mm);
			}
		}
	catch (MobileException e)
	{
		System.out.println(e.getMessage());
	}
}	
}
