package com.cg.mps.bean;

import java.sql.Date;

public class Purchase 
{
	private int purchaseId;
	private String cName;
	private String mailId;
	private String phoneNo;
	private Date purchaseDate;
	private Mobile mobileId;
	
	public int getPurchaseId() 
	{
		return purchaseId;
	}
	public void setPurchaseId(int purchaseId) 
	{
		this.purchaseId = purchaseId;
	}
	public String getcName() 
	{
		return cName;
	}
	public void setcName(String cName)
	{
		this.cName = cName;
	}
	public String getMailId() 
	{
		return mailId;
	}
	public void setMailId(String mailId) 
	{
		this.mailId = mailId;
	}
	public String getPhoneNo() 
	{
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) 
	{
		this.phoneNo = phoneNo;
	}
	public Date getPurchaseDate() 
	{
		return purchaseDate;
	}
	public void setPurchaseDate(Date purchaseDate) 
	{
		this.purchaseDate = purchaseDate;
	}
	public Mobile getMobileId()
	{
		return mobileId;
	}
	public void setMobileId(Mobile mobileId)
	{
		this.mobileId = mobileId;
	}
	public Purchase()
	{
		super();
	}
	public Purchase(int purchaseId, String cName, String mailId,
			String phoneNo, Date purchaseDate, Mobile mobileId) 
	{
		super();
		this.purchaseId = purchaseId;
		this.cName = cName;
		this.mailId = mailId;
		this.phoneNo = phoneNo;
		this.purchaseDate = purchaseDate;
		this.mobileId = mobileId;
	}
	@Override
	public String toString() 
	{
		return "Purchase [purchaseId=" + purchaseId + ", cName=" + cName
				+ ", mailId=" + mailId + ", phoneNo=" + phoneNo
				+ ", purchaseDate=" + purchaseDate + ", mobileId=" + mobileId
				+ "]";
	}
}
