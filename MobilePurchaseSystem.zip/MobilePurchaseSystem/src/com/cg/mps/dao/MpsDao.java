package com.cg.mps.dao;
import java.util.ArrayList;
import com.cg.mps.bean.Mobile;
import com.cg.mps.bean.Purchase;
import com.cg.mps.exception.MobileException;
public interface MpsDao 
{
	public int addMps(Mobile mps) throws MobileException;
	public ArrayList<Mobile> getAllMps() throws MobileException;//returns array list of all employees
	public int updateMob(int mobId) throws MobileException;
	public int deleteMob(int mobId) throws MobileException;
	
	public ArrayList<Mobile> getSearchMps(int price1,int price2) throws MobileException;
	public int addPur(Purchase pur,Mobile mps) throws MobileException;
	public int generatePurchaseId() throws MobileException;
	public int getMobileId() throws MobileException;
}
