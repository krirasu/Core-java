package com.cg.mps.dao;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import com.cg.mps.bean.Mobile;
import com.cg.mps.bean.Purchase;
import com.cg.mps.exception.MobileException;
import com.cg.mps.util.DBUtil;

public class MpsDaoImpl implements MpsDao
{
	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	Logger mpsLogger=null;
	
	public MpsDaoImpl()
	{
	}
	
	@Override
	public int addMps(Mobile mps) throws MobileException 
	{
		String insertQry="INSERT INTO mobiles(mobileId,Name,Price,Quantity) Values(?,?,?,?)";
		int dataAdded=0;
		try 
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(insertQry);
			pst.setInt(1,mps.getMobileId());
			pst.setString(2,mps.getMobName());
			pst.setFloat(3,mps.getMobPrice());
			pst.setInt(4,mps.getMobQuantity());
			
			dataAdded=pst.executeUpdate();
					
		} 
		catch (Exception e) 
		{
			throw new MobileException(e.getMessage());
		} 
		finally
		{
			try 
			{
				pst.close();
				con.close();
			} 
			catch (Exception e) 
			{
				throw new MobileException(e.getMessage());
			}
		}
		return dataAdded;
	}
			
	@Override
	public int updateMob(int mobId) throws MobileException 
	{
		String updateQry="UPDATE mobiles set quantity=quantity-1 where mobileId=?";
		int dataUpdated=0;
		try 
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(updateQry);
			pst.setInt(1,mobId);
			dataUpdated=pst.executeUpdate();
			
		} 
		catch (Exception e) 
		{
			throw new MobileException(e.getMessage());
		} 
		finally
		{
			try 
			{
				pst.close();
				con.close();
			} 
			catch (Exception e) 
			{
				throw new MobileException(e.getMessage());
			}
		}
		return dataUpdated;
	}
	
	@Override
	public ArrayList<Mobile> getAllMps() throws MobileException 
	{
		ArrayList<Mobile> mpsList=new ArrayList<Mobile>();
		String selectQry="SELECT * FROM mobiles";
		Mobile mb = null;
		try
		{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(selectQry);
			while(rs.next())
			{
				mb=new Mobile(rs.getInt("mobileId"),rs.getString("Name"),rs.getFloat("Price"),rs.getInt("Quantity"));
				mpsList.add(mb);
			}
		}
		catch (Exception e)
		{
			throw new MobileException(e.getMessage());
		}
		finally
		{
			try 
			{
				rs.close();
				con.close();
				st.close();
			} 
			catch (SQLException e) 
			{
				throw new MobileException(e.getMessage());
			}
		}
		return mpsList;
	}
	@Override
	public int deleteMob(int mobId) throws MobileException 
	{
		
		String deleteQry="DELETE from mobiles where mobileId=?";
		int dataDeleted=0;
		try 
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(deleteQry);
			pst.setInt(1,mobId);
			dataDeleted=pst.executeUpdate();
			
		} 
		catch (Exception e) 
		{
			throw new MobileException(e.getMessage());
		} 
		finally
		{
			try 
			{
				pst.close();
				con.close();
			} 
			catch (SQLException e) 
			{
				throw new MobileException(e.getMessage());
			}
		}
		return dataDeleted;

	}
	@Override
	public ArrayList<Mobile> getSearchMps(int price1,int price2) throws MobileException 
	{
		ArrayList<Mobile> mList=new ArrayList<Mobile>();
		String searchQry="SELECT * FROM mobiles WHERE Price BETWEEN ? AND ?";
		Mobile mSearch = null;
		try
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(searchQry);
			pst.setInt(1,price1);
			pst.setInt(2,price2);
			rs=pst.executeQuery();
			while(rs.next())
			{
				mSearch=new Mobile(rs.getInt("mobileId"),rs.getString("Name"),rs.getFloat("Price"),rs.getInt("Quantity"));
				mList.add(mSearch);
			}
		}
		catch (Exception e)
		{
			throw new MobileException(e.getMessage());
		}
		finally
		{
			try 
			{
				rs.close();
				con.close();
				pst.close();
			} 
			catch (SQLException e) 
			{
				throw new MobileException(e.getMessage());
			}
		}
		return mList;
	}
	@Override
	public int addPur(Purchase pur,Mobile mps) throws MobileException 
	{
		String insertQry="INSERT INTO purchasedetails(purchaseId,cName,mailId,phoneNo,purchaseDate,mobileId) Values(?,?,?,?,sysdate,?)";
		int dataAdded=0;
		try 
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(insertQry);
			pst.setInt(1,generatePurchaseId());
			pst.setString(2,pur.getcName());
			pst.setString(3,pur.getMailId());
			pst.setString(4,pur.getPhoneNo());
			pst.setInt(5,mps.getMobileId());
			dataAdded=pst.executeUpdate();
		} 
		catch (Exception e) 
		{
			throw new MobileException(e.getMessage());
		} 
		finally
		{
			try 
			{
				pst.close();
				con.close();
			} 
			catch (Exception e) 
			{
				throw new MobileException(e.getMessage());
			}
		}
		updateMob(mps.getMobileId());
		return dataAdded;
	}
	@Override
	public int generatePurchaseId() throws MobileException
	{
		String qry="SELECT pur_seq.NEXTVAL FROM DUAL";
		int generatedVal;
		try 
		{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(qry);
			rs.next();
			generatedVal=rs.getInt(1);
		} 
		catch (Exception e) 
		{
			throw new MobileException(e.getMessage());
		}
		finally
		{
			try 
			{
				rs.close();
				con.close();
				st.close();
			} 
			catch (Exception e) 
			{
				throw new MobileException(e.getMessage());
			}
		}
		return generatedVal;
	}

	@Override
	public int getMobileId() throws MobileException 
	{
		String selectQry="SELECT mobileId FROM mobiles";
		int dataAdded=0;
		Mobile mps = null;
		try
		{
			mps=new Mobile();
			con=DBUtil.getCon();
			pst=con.prepareStatement(selectQry);
			pst.setInt(1,mps.getMobileId());
			dataAdded=pst.executeUpdate();	
		}
		catch (Exception e)
		{
			throw new MobileException(e.getMessage());
		}
		finally
		{
			try 
			{
				rs.close();
				con.close();
				st.close();
			} 
			catch (Exception e) 
			{
				throw new MobileException(e.getMessage());
			}
		}
		return dataAdded;
	}
}

