package com.cg.mps.service;
import java.util.ArrayList;

import com.cg.mps.bean.Mobile;
import com.cg.mps.bean.Purchase;
import com.cg.mps.exception.MobileException;

public interface MpsService 
{
	public int addMps(Mobile mps) throws MobileException;
	public ArrayList<Mobile> getAllMps() throws MobileException;
	public int updateMob(int mobId) throws MobileException;
	public int deleteMob(int mobId) throws MobileException;
	public ArrayList<Mobile> getSearchMps(int price1,int price2) throws MobileException;
	public int addPur(Purchase pur,Mobile mps) throws MobileException;
	public int generatePurchaseId() throws MobileException;
	public int getMobileId() throws MobileException;
				
	public boolean validateName(String cName) throws MobileException;
	public boolean validateMail(String mailId) throws MobileException;
	public boolean validateDigit(String phoneNo) throws MobileException;

	public boolean validateDigit(int mobileId) throws MobileException;
}

