package com.cg.mps.service;

import java.util.ArrayList;
import java.util.regex.Pattern;
import com.cg.mps.bean.Mobile;
import com.cg.mps.bean.Purchase;
import com.cg.mps.dao.MpsDao;
import com.cg.mps.dao.MpsDaoImpl;
import com.cg.mps.exception.MobileException;


public class MpsServiceImpl implements MpsService
{
	MpsDao mpsDao=null;
	public MpsServiceImpl()
	{
		mpsDao=new MpsDaoImpl();
	}
	@Override
	public int addMps(Mobile mps) throws MobileException 
	{
		return mpsDao.addMps(mps);
	}

	@Override
	public ArrayList<Mobile> getAllMps() throws MobileException 
	{
		return mpsDao.getAllMps();
	}

	@Override
	public int updateMob(int mobId) throws MobileException 
	{
		return mpsDao.updateMob(mobId);
	}

	@Override
	public int deleteMob(int mobId) throws MobileException
	{
		return mpsDao.deleteMob(mobId);
	}

	@Override
	public ArrayList<Mobile> getSearchMps(int price1,int price2) throws MobileException
	{
		return mpsDao.getSearchMps(price1, price2);
	}

	@Override
	public int addPur(Purchase pur,Mobile mps) throws MobileException 
	{
		return mpsDao.addPur(pur,mps);
	}

	@Override
	public int generatePurchaseId() throws MobileException 
	{
		return mpsDao.generatePurchaseId(); 
	}
	
	@Override
	public int getMobileId() throws MobileException
	{
		return mpsDao.getMobileId();
	}

	@Override
	public boolean validateName(String cName) throws MobileException 
	{
		String namePattern="[A-Z][a-z]{1,20}";
		if(Pattern.matches(namePattern, cName))
		{
			return true;
		}
		else
		{
			throw new MobileException("Only 20 Chars Allowed and starts with Capital");
		}
	}

	@Override
	public boolean validateMail(String mailId) throws MobileException
	{
		String mailPattern="^(.+)@(.+)$";
		if(Pattern.matches(mailPattern, mailId))
		{
			return true;
		}
		else
		{
			throw new MobileException("Only valid emailId is allowed");
		}
	}

	@Override
	public boolean validateDigit(String phoneNo) throws MobileException 
	{
		String numPattern="[0-9]{10}";
		if(Pattern.matches(numPattern, phoneNo))
		{
			return true;
		}
		else
		{
			throw new MobileException("Only 10 digits are allowed");
		}
	}
	@Override
	public boolean validateDigit(int mobileId) throws MobileException 
	{
		String numPattern="[0-9]{4}";
		if(Pattern.matches(numPattern, new Integer(mobileId).toString()))
		{
			return true;
		}
		else
		{
			throw new MobileException("Only min 4 digits allowed in mobId");
		}
	}
}
