package com.cg.springdemomvcone.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.springdemomvcone.dao.IEmployeeDao;
import com.cg.springdemomvcone.dto.Employee;

@Service("employeeservice")
@Transactional
public class EmployeeServiceImpl implements IEmployeeService {

	@Autowired
	IEmployeeDao employeedao;
	@Override
	public void addEmployeeData(Employee emp) {
		employeedao.addEmployeeData(emp);// TODO Auto-generated method stub

	}

	@Override
	public List<Employee> showAllEmployee() {
		return employeedao.showAllEmployee();
		
	}

	@Override
	public void deleteEmployee(int empId) {
		// TODO Auto-generated method stub

	}

	@Override
	public void updateEmployee(Employee emp) {
		// TODO Auto-generated method stub

	}

	@Override
	public Employee searchEmployee(int id) {
		// TODO Auto-generated method stub
		return null;
	}

}
